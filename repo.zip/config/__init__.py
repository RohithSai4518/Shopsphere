# ShopSphere Django Configuration Package
