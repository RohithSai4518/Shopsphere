# ShopSphere Django Applications Package
